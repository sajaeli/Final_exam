@extends('layouts.app')

@section('content')

    <h2>Welcome</h2>
    
@endsection
